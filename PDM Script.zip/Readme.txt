Thanks for downloading Premium Deluxe Motorsports Car Dealership Mod v4.5 by I'm Not MentaL.
If you like this mod, please like, rate, comment and subscribe, also Donate :)
And also I recommended to use this mod together with Single Player Apartment or Persistence 2. 

Features:
This mod brings Car Dealership into GTA V. Adds Unlimited Choice of Colors, Customize Plate Number, Test Drive and Preview.

Requirements:
- Latest ScriptHookV
- Latest Community Script Hook V .NET

Install:
1. Make sure you have all the Requirements Installed.
2. Extract, Drag and Drop the contents into 'scripts' Folder. Create one if you don't have it.
3. Profit.

Changelog:
v4.5.1
- Fixed Itali GTB Custom price.

v4.5
- Added The Los Santos Summer Special update vehicles.
- Added support for controller.
- Updated Globals.
- Updated INMNativeUI to 1.8.608.3.

v4.4.5
- Added The Diamond Casino Heist update vehicles.
- Updated Globals.
- Updated INMNativeUI to 1.8.1019.1.

v4.4.4
- Added The Diamond Casino & Resort update vehicles.
- Updated Globals.
- Added French, Italian & Portuguese translation.

v4.4.3
- Fixed instructional button not reacting to custom mapped buttons.

v4.4.2
- Added control button remapping.

v4.4.1
- Fixed game text missing on Ammu-nation.

v4.4
- Added Chinese Simplified support.
- Script improvements.

v4.3
- Script improvement and bugs fixed.
- Added Arena War update vehicles.

v4.2.9
- Added After Hours update vehicles.

v4.2.8
- Fixed Secondary Metallic Color bug.
- Improvements to the script.

v4.2.7
- Corrected Motorcycle spelling.
- Combined Open/Close Door into 1 button.
- Added Roof Control Instructional Button.
- Changed Camera Control to Bike Sprint button (Capslock on keyboard).
- Added Zoom button (Left Shift on keyboard).

v4.2.6
- Vehicles are now displaying newest to oldest.
- Fixed the Salesgirl glitch.
- Added missing Weeny Issi Classic from Southern San Andreas Super Sport Series update.
- Added a star on every newly added vehicles.

v4.2.5
- Added Option to Not Generate Error Log.
- Improvements to the script.
- Added Southern San Andreas Super Sport Series update vehicles.

v4.2.4b
- INMNativeUI updated: fixes "NULL".

v4.2.4
- INMNativeUI updated: Shows stats of the vehicle. 
- Removed old Show stats method.

v4.2.3
- Test drive bugs fixed.
- Added The Doomsday Heist update vehicles.
- INMNativeUI updated: Improve FPS while using this mod.

v4.2.2 Patreon release
- Bugs fixes and improvement.

v4.2.1
- Bugs fixes and improvement.

v4.2
- Dynamic Categories (Add as many as you want!).
- Added Smuggler's Run update vehicles.
- Enter & Exit Cutscene removed due to many complaint.
- View Stats Instruction Button Added.
- Dealership Entrance position moved to front desk.
- PDMTool update

v4.1
- Bugs fixes and improvement.
- Added Gunrunning update vehicles.
- Vehicle Info Added (Press Z on keyboard).

v4.0.1
- Bugs fixes for v4.0.
- PDMTool added for easier Add/Remove vehicles and Import Vehicle from vehicles.meta.
- Added Cunning Stunts: Special Vehicle Circuit update vehicles.
- Change Camera key change to Handbrake button (Spacebar/RB)

v4.0
- New 360 Angle Camera (Replace Spin).
- New Interior Camera.
- Enter Exit Cutscenes.
- Upgrade Effects and Sounds.
- New Color Menu.
- Merge Lowrider Category with Muscle, Sedan, Van and Sport Classic.

Source Code:
https://github.com/qiangqiang101/PremiumDeluxeMotorsport.NET

Credits: 
Alexander Blade for ScriptHookV
Crosire for Community ScriptHookVDotNet
Guad for Camera & NativeUI Base
EnergyStyle, LetsPlayOrDy, Calm, LCBuffalo, Gang1111, Matt_STS, frodzet, leftas, marhex & CamxxCore for the Help
Anthonyamd for French translation
pnda for German translation
Krazy for Italian & Portuguese translation
Mell for Korean translation
大雪熊OwO for Japanese translation
Gixer & david for Spanish translation
MMK_033 ofr Russian translation
