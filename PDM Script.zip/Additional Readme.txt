=== Your Created Category is NULL in menu ===
1. Open up 'scripts\PremiumDeluxeMotorsport\Languages\*your_game_language*.cfg'
2. Find 'commercial "Commercial"' then add a new line
For example your category name is 'IV Pack' and the category file is 'ivpack.ini'
3. Enter 'ivpack "IV Pack"'
4. Save the file and start GTAV.

=== Script Hook V Critical Error ===
Symtomps: Your Computer Name has Unicode Characters and Script Hook V aren't support it.
1. Open up 'scripts\PremiumDeluxeMotorsport\config.ini'
2. Find 'REMOVESPRITE = False'
3. Change to 'REMOVESPRITE = True'
4. Save the file and start GTAV.

=== You want to disable Fade in/out Effect ===
1. Open up 'scripts\PremiumDeluxeMotorsport\config.ini'
2. Find 'FADEEFFECT = True'
3. Change to 'FADEEFFECT = False'
4. Save the file and start GTAV.

=== You want the Game to use vehicles' default color ===
1. Open up 'scripts\PremiumDeluxeMotorsport\config.ini'
2. Find 'RANDOMCOLOR = True'
3. Change to 'RANDOMCOLOR = False'
4. Save the file and start GTAV.

=== You don't want the script to generate logs ===
1. Open up 'scripts\PremiumDeluxeMotorsport\config.ini'
2. Find 'LOGGING = True'
3. Change to 'LOGGING = False'
4. Save the file and start GTAV.
