Thanks for downloading Flatbed Script by I'm Not MentaL.
Please donate some bucks if you enjoy this mod.

<b>Requirements:</b>
- Latest ScriptHookV 
- Latest Community Script Hook V .NET 
- Flatbed Vehicle

<b>Install:</b>
1. Extract the files anywhere
2. Drag and Drop all the files into your GTAV Scripts Folder.
3. Profit.

<b>Keys:</b>
Keyboard
VehicleDuck (Standing on the back) - Unload Vehicle on Bed
VehicleDuck (Driving a vehicle towards the bed) - Load Vehicle on Bed
VehicleDuck - Lift/Lower the bed (auto)
VehicleSubAscend/Descend - Lift/Lower the bed (manual)

Controller
Hold ScriptRB and Press ScriptPadUp/Down - Lift/Lower the bed (manual)

If you don't know what is the keys meaning, goto SETTINGS > Key Bindings in GTA V Pause Menu.
By default on controller is A button, keyboard is X button.

<b>Fun Fact:</b>
Center your steering so it won't turn around.

<b>Changelog:</b>
v1.5
- Fixed lift/lower bed controls while in other vehicles.
- Improved controls while playing using Xbox controller.

v1.4
- Added extra part move function (required by Peterbilt 337 Jerrdan).
- Lowered the markers.

v1.3
- Fixed the stuttering problem when truck isn't moving/revving.
- Now you can manually control the bed lift/lower.
- Added outside control panel (requires flatbed that supports).

v1.2
- Added winch sensor (will stop whenever something is blocking the way).
- You can now load vehicles facing backwards.
- Bugs fixes and improvements.

v1.1
- Winch no longer hooks when player is inside vehicle.
- Player no longer unloads when bed is not lowered.
- Fixed vehicle keeps going backwards when unloading.

v1.0
- Initial Release

<b>Credits:</b>
Rockstar Games for the original model
Alexander Blade for ScriptHookV
Crosire for ScriptHookVDotNet
UnknownModder for Decor Unlocker
Smallto for the help
Mell for Korean translation
Krazy! for Portuguese & Italian translation
Gixer for Spanish translation
pnda for German translation
��ѩ��0w0 for Japanese translation
Anthony for French translation