To make the script work for your model. You need to have these following nodes:
- scoop = bed
- misc_a = where to car attach to
- misc_b = where the winch rope coming from
- misc_e = (Optional) where the control panel is
- misc_f = (Optional) where the 2nd control panel is
* misc_a & misc_b's parent is set to scoop.

Create a xml file, paste the content below:

<?xml version="1.0" encoding="utf-8"?>
<FlatbedData xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
	<Model>your_model</Model>
	<AttachDummy>misc_a</AttachDummy>
	<WinchDummy>misc_b</WinchDummy>
	<ControlDummy>misc_e</ControlDummy>
	<ControlDummy2>misc_f</ControlDummy2>
	<ControlIsOutside>true</ControlIsOutside>
	<EnableExtraDoor>false</EnableExtraDoor>
	<ExtraDoorMove>Trunk</ExtraDoorMove>
	<ExtraDoorAngleAdjustment>0</ExtraDoorAngleAdjustment>
</FlatbedData>

- Model = your truck model
- AttachDummy = attach dummy, default use misc_a
- WinchDummy = winch dummy, default use misc_b
- ControlDummy (Optional) control 1 dummy, default use misc_e, leave blank if you don't have controls outside of your vehicle
- ControlDummy2 (Optional) control 2 dummy, default use misc_f, leave blank if you don't have controls outside of your vehicle
- ControlIsOutside = if the above options are active, put true, else, put false
- EnableExtraDoor = move extra parts, default is false
- ExtraDoorMove = the parts that you want to move, options: FrontLeftDoor, FrontRightDoor, BackLeftDoor, BaclRightDoor, Hood, Trunk
- ExtraDoorAngleAdjustment = adjustment for ExtraDoorMove options, default is 0

Name it your_model.xml
Place it on GTAV\scripts\Flatbed\Vehicles

That's it.