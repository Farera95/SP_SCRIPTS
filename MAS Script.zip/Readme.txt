Thanks for downloading Mosley Auto Service Mod by I'm Not MentaL.
If you like this mod, please like, rate, comment and subscribe, also Donate :)

Description:
This mod add a whole new Dealership and Auto Service in GTAV. In other words, this is a Premium Deluxe Motorsport plus Benny's Original Motor Works combined.

Requirements:
- Latest ScriptHookV
- Latest Community Script Hook V .NET
- Visual C++ Redistributable Packages x64
- Latest Microsoft .NET Framework according to SHVDN
- Mosley's Auto Shop (MLO) [SP / FiveM] (https://www.gta5-mods.com/maps/mosley-s-auto-shop-interior-sp-fivem)

Install:
1. Make sure you have all Requirements Installed. 
2. Extract, Drag and Drop the files into your scripts Folder. 

Settings:
Open config.ini with Notepad or other Text file editor you prefer.
Settings are same as SPB and PDM, added Parked vehicles you can change with.

Changelog:
v1.1
- Update to latest DLC Global Value.
- Update to support Nitro for all Vehicles v1.3.
- Fixed Open Wheel vehicle's engine and bumper camera issue.
- Added The Los Santos Summer Special update vehicles.
- Added latest wheel option from The Los Santos Summer Special DLC.
- Added latest Vehicle upgrade from The Los Santos Summer Special DLC.
- Update Metadata to 1.2.101.2.
- Fixed Itali GTB Custom price.
- Updated INMNativeUI to 1.8.608.3.

v1.0 Rel
- Fixed Arena War vehicle upgrade bug.
- Fixed Nitro bug.

v1.0 Public Beta
- Combined SPB and PDM into a single mod.

Credits: Honeynutt Customs
