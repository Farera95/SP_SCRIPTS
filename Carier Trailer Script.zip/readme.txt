Thanks for downloading Car Carrier Trailer Mod by I'm Not MentaL

Features:
- Lower/Raise Trailer Deck
- Drop Ramp
- Detach Trailer from Truck
- Attach Vehicles to Trailer (So it won't fall when driving)
- Repair Trailer
- Spawn a Truck & Trailer

Requirements:
- Latest ScriptHookV 
- Latest Community Script Hook V .NET 
- Visual C++ Redistributable for Visual Studio 2013 x64
- Microsoft .NET Framework 4.5.2 

Install:
Drag and Drop contents indside 'Install' folder into GTAV Main Directory. 
To Open Menu Press Shift + B (Keyboard)/Dpad Right + Y (Xbox Controller) by default.

Setting:
Open CarCarrierTrailerMod.ini
PRIMARY/PADPRIMARY = Primary Key
SECONDARY/PADSECONDARY = Secondary Key

If the mod CRASH while attaching or car FLOATING, Open CarCarrierTrailerMod.ini then Press Ctrl+H then find "." replace with "," then hit save, now start the game and try again. 

Changelog:
v1.2
- Automatically Calculate the coordinates, no need to set manually on CarCarrierTrailerMod.ini.
- All Vehicle Class added (Yes Police cars, Boats, Helicopters, Motorbikes, etc).

v1.1
- Separate Attach/Detach Vehicles to another Menu
- Controller Support
- Cars Attached to Trailer Collision fixed
- If Trailer Exploded, all the attached vehicles will detach and fall off
- Minor bug fixes and improvements. 

v1.0
- Initial Release

Credits:
Rockstar Games, Alexander Blade, Crosire, Guadmaz